g++ working.cpp RideReport.cpp #Skompilowany plik z poprawnymi danymi
Test_1.cpp RideReport.cpp #Test1 - przekazanie konstruktorowi wskaźnika pustego
Test_2.cpp RideReport.cpp #Test2 - przekazanie konstruktorowi nazwy nieistniejącego pliku
Test_3.cpp RideReport.cpp #Test3 - przekazanie konstruktorowi nazwy pustego pliku "no_data.txt"
Test_4.cpp RideReport.cpp #Test4 - przekazanie konstruktorowi nazwy pliku nie zwierającego znaków żadnego ze znaków z zestawu aAbBlLrR. "wrong_data.txt"